<?php
#para iniciar sesión se usa session_start()
session_start();

if(isset($_POST)){
    $_SESSION['nombre'] = $_POST["nombre"];
    $_SESSION['clave'] = $_POST["clave"];
    header("Location:mipanel.php");
}else{
    header("Location:index.php");
}

?>