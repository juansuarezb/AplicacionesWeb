<html>
    <head>
        <title>Mi sistema</title>
    </head>
    <body>
        <h1>LOGIN</h1>
        <form action="autorizar.php" method="POST">
            Usuario:<br>
            <input type="text" name="nombre"/><br>
            Clave:<br>
            <input type="password" name="clave"/><br>
            <input type="submit" name="btnEnviar"/>
        </form>
    </body>
</html>