<?php
#crear sesión o reiniciar una preexistente
session_start();

#Validar que las sesiones existen y no son vacías (También para SESSION[clave])
if($_SESSION["nombre"]=="" || $_SESSION["nombre"]== null){
    header("Location:index.php");
}

?>

<html>
    <head>
    </head>
    <body>
        <h1>PANEL PRINCIPAL</h1>
        <h3>Bienvenido Usuario: <?php echo $_SESSION["nombre"];  ?></h3>
        <p><a href="cerrarsesion.php">Cerrar Sesion</a></p>
    </body>
</html>